#include <stdio.h>
#include<stdlib.h>

int G, F, Q,D;

int main(void)
{
	printf("�п�J�T�Ӿ�ơG\n");
	scanf_s("%d%d%d", &G, &F, &Q);
	if (G > F)
	{
		D = G;
		G = F;
		F = D;
	}
	if (F > Q)
	{
		D = F;
		F = Q;
		Q = D;
	}
	if (G > F)
	{
		D = G;
		G = F;
		F = D;
	}
	printf("largest  number is %d\n", Q);
	printf("smallest number is %d\n",G);
	system("pause");
	return 0;
}