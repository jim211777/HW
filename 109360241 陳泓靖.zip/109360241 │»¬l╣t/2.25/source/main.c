#include <stdio.h>
#include<stdlib.h>

int main(void)
{

	printf("   CCCCC\n");
	printf(" C       C\n");
	printf("C         C\n");
	printf("C         C\n");
	printf(" C       C\n\n");
	printf("HHHHHHHHH\n");
	printf("    H\n");
	printf("    H\n");
	printf("    H\n");
	printf("HHHHHHHHH\n\n");
	printf("   CCCCC\n");
	printf(" C       C\n");
	printf("C         C\n");
	printf("C         C\n");
	printf(" C       C\n\n");






}