#include <stdio.h>
#include<stdlib.h>
int main(void)
{
	int sum;
	while (scanf_s) {
		printf("�п�J�Ʀr:\n");
		scanf_s("%d", &sum, "\n");
		if (sum == 1)
		{
			printf("�����O%d", sum, "\n");
		}
		else if (sum % 2 == 0)
		{
			printf("����:%d", sum, "\n");
		}
		else if (sum % 2 != 0)
		{
			printf("�_��:%d", sum, "\n");
		}
	}
	system("pause");
	return 0;
}